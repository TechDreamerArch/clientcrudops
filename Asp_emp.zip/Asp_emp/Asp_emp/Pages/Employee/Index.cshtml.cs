using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Asp_emp.Pages.Employee
{
    public class IndexModel : PageModel
    {
        private readonly IConfiguration _configuration;
        public List<EmpInfo> listemp = new List<EmpInfo>();

        public IndexModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public void OnGet()
        {
            try
            {
                //fetch the connection string from appsettings.json
                string connectionStrings = _configuration.GetConnectionString("DefaultConnection");

                using(SqlConnection connection=new SqlConnection(connectionStrings))
                {
                    connection.Open();
                    String sql = "SELECT * FROM Employee";
                    using(SqlCommand command=new SqlCommand(sql, connection))
                    {
                        using(SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                EmpInfo empInfo = new EmpInfo();
                                empInfo.id = "" + reader.GetInt32(0);
                                empInfo.fname = reader.GetString(1);
                                empInfo.lname = reader.GetString(2);
                                empInfo.email = reader.GetString(3);
                                empInfo.phone = reader.GetString(4);
                                empInfo.hiredate = reader.GetDateTime(5).ToString();
                                empInfo.salary = reader.GetDecimal(6);

                                listemp.Add(empInfo);

                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
    }
    public class EmpInfo
    {
        public String id;
        public String fname;
        public String lname;
        public String email;
        public String phone;
        public String hiredate;
        public decimal salary;
        // Change to decimal
    }

}
